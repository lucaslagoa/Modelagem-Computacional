import java.util.ArrayList;
import java.util.List;

import ec.util.MersenneTwisterFast;
import sim.engine.*;
import sim.field.continuous.*;
import sim.field.grid.Grid2D;
import sim.field.grid.SparseGrid2D;
import sim.util.*;
import sim.field.network.*;

public class Student implements Steppable
{
	public static final double MAX_FORCE = 3.0;
	
	
	//double friendsClose = 0.0; // initially very close to my friends
	//double enemiesCloser = 10.0; // WAY too close to my enemies
	//public double getAgitation() { return friendsClose + enemiesCloser; }
	
	
	public MersenneTwisterFast random;
	public int cor; 	
	private SparseGrid2D domain; 
	private Students students;
	public Int2D me;
	private Region region;
	private Bag near_neighbors;
	private IntBag near_locations_x;
	private IntBag near_locations_y;
	private double evaluation; 
	private List<Student> friends = new ArrayList<>();
	private double segregationDegree;
	private int raio1 = 5;
	private int raio2 = 10;
	private int raio3 = 20;
	public double getSegregationDegree() {
		return segregationDegree;
	}

	public void setSegregationDegree(double segregationDegree) {
		this.segregationDegree = segregationDegree;
	}


	private double numberOfNeighboursSameColor;
	private double numberOfNeighbours;
	
	public void setCor(int c)
	{
		this.cor = c;
	}
	
	public int getCor()
	{
		return cor;
	}	
	
	public String toString() 
	{ 
		/*Int2D location;
		if(students != null)
		{
			location = students.domain.getObjectLocation(this);
			return "[" + System.identityHashCode(this) + "] position: (" + location.getX() + "," + location.getY() + "); cor: " + getCor() 
			+ "; Grau de segregação: " + segregationDegree + "; Num de vizinhos mesma cor: " + numberOfNeighboursSameColor + 
			"; Total vizinhos: " + numberOfNeighbours; 
		}
		else return "[" + System.identityHashCode(this) + "] cor: " + getCor() + "; Grau de segregação: " + this.segregationDegree
				+ "; Num de vizinhos mesma cor: " + numberOfNeighboursSameColor + "; Total vizinhos: " + numberOfNeighbours; 
		*/
		return " ";
	}
	
	public void addFriend(Student s)
	{
		friends.add(s);
	}
	
	//public Student searchFriend()
	
	public void makeEvaluation()
	{
		this.evaluation = random.nextDouble();
		region.addEvaluation(this.evaluation);
	}
	
	public boolean Move()
	{
		Student near_student;
		double dif_ql, dif_cost, sum = 0, medium = 0, p, prob_ascending;
		///consulta as avaliações enviadas por um grupo pequeno de estudantes amigos aleatórios 
		this.domain.getRadialNeighbors(me.getX(), me.getY(), 3, Grid2D.BOUNDED, false, near_neighbors, near_locations_x, near_locations_y);
		for(int i = 0; i < near_neighbors.size(); i++)
		{
			 near_student = (Student)near_neighbors.get(i);
			 if(! near_student.getRegion().getName().equals(this.getRegion().getName()) ) ///Tenta mudar se possui algum vizinho em outra região 
			 {
				 dif_ql = near_student.getRegion().getQl() - this.getRegion().getQl(); 
				 dif_cost = Math.abs(near_student.getRegion().getCost() - this.getRegion().getCost());
				 if(dif_ql < 0)
					 dif_ql = 0;
				 prob_ascending = random.nextDouble()*0.15;
				 if(dif_cost != 0)
					 p = (dif_ql/dif_cost)*0.1 + this.getRegion().getNptc() + medium*0.1 + prob_ascending;
				 else 
					 p = (dif_ql)*0.1 + this.getRegion().getNptc() + medium*0.1 + prob_ascending;
				 if(p >= 0.45)
				 {
					 ///Guarda a posição de destino para onde o estudante irá se mover 
					 return true;
				 }								 
				 else				 
					 return false; 
				 
			 }
		}
		return false;
	}
	
	public void step0(SimState state)
	{
		students = (Students) state;
		domain = students.domain;
		me = students.domain.getObjectLocation(this);
		random = new MersenneTwisterFast(System.currentTimeMillis());
				
		/*if(students.region2.inRegion(me.x, me.y))
		{
			System.out.println("Student " + this + "está na região 2.");
		}*/
		
		///**CALL Move
		
		//Bag neighbours = 
		Bag neighbours;
		IntBag vetor_posicoes_x = new IntBag(), vetor_posicoes_y = new IntBag();
		neighbours = students.domain.getRadialNeighbors(me.x, me.y, 2, Grid2D.BOUNDED, false); //, includeOrigin, measurementRule, closed, result, xPos, yPos)
		//neighbours = students.domain.getMooreNeighbors(pos_atual.getX(), pos_atual.getY(), 2, Grid2D.BOUNDED, false);
		
		//neighbours = students.domain.getMooreNeighborsAndLocations(pos_atual.getX(), pos_atual.getY(), 2, Grid2D.BOUNDED, neighbours, vetor_posicoes_x, vetor_posicoes_y);
		//getNeighborsExactlyWithinDistance(students.yard.getObjectLocation(this), 0.5, false);  Continuos2D
		
		MutableDouble2D directionVector = new MutableDouble2D();
		MutableDouble2D sumDirections = new MutableDouble2D();
		
		
		Bag neighboursSameColor = new Bag();
		Student neighbour;
		for(int i = 0; i < neighbours.size(); i++)
		{
			neighbour = (Student)neighbours.get(i);
			if(neighbour.getCor() == this.getCor())
			{
				neighboursSameColor.add(neighbour);						
			}			
			//System.out.println(neighbour.getAgitation());
		}
		
		numberOfNeighbours = neighbours.size();
		numberOfNeighboursSameColor = neighboursSameColor.size();
		if(neighbours.size() == 0.0)
			this.segregationDegree = 0.0;
		else 
			this.segregationDegree = numberOfNeighboursSameColor/numberOfNeighbours;
	}

	@SuppressWarnings("unused")
	public void step(SimState state)
	{
		//Students 
		students = (Students) state;
		//Continuous2D yard = students.yard;
		
		domain = students.domain;
//		Int2D me
		me = students.domain.getObjectLocation(this);
		
//		Double2D me = students.yard.getObjectLocation(this);
		//MutableDouble2D sumForces = new MutableDouble2D();
		
		random = new MersenneTwisterFast(System.currentTimeMillis());		

//		Bag out = students.buddies.getEdges(this, null);
//		int len = out.size();
//		for(int buddy = 0 ; buddy < len; buddy++)
//		{
//			Edge e = (Edge)(out.get(buddy));
//			double buddiness = ((Double)(e.info)).doubleValue();
//			// I could be in the to() end or the from() end. getOtherNode is a cute function
//			// which grabs the guy at the opposite end from me.
//			Int2D him = students.domain.getObjectLocation(e.getOtherNode(this));
//			//Double2D him = students.yard.getObjectLocation(e.getOtherNode(this));
//			if (buddiness >= 0) // the further I am from him the more I want to go to him
//			{
//				if(forceVector!=null){
//					forceVector.setTo((him.x - me.x) * buddiness, (him.y - me.y) * buddiness);
//					if (forceVector.length() > MAX_FORCE) // I’m far enough away
//						forceVector.resize(MAX_FORCE);
//					friendsClose += forceVector.length();
//				}
//				
//			}
//			else // the nearer I am to him the more I want to get away from him, up to a limit
//			{
//				forceVector.setTo((him.x - me.x) * buddiness, (him.y - me.y) * buddiness);
//				if (forceVector.length() > MAX_FORCE) // I’m far enough away
//					forceVector.resize(0.0);
//				else if (forceVector.length() > 0)
//					forceVector.resize(MAX_FORCE - forceVector.length()); // invert the distance
//				enemiesCloser += forceVector.length();
//			}
//			sumForces.addIn(forceVector);
//		}
		
		Int2D pos_atual = new Int2D(students.domain.getObjectLocation(this).x, 
				students.domain.getObjectLocation(this).y);
		
		/*if(students.region2.inRegion(pos_atual.getX(), pos_atual.getY()))
		{
			System.out.println("Student " + this + "está na região 2.");
		}*/
		
		///**CALL Move
		
		//Bag neighbours = 
		Bag neighbours;
		IntBag vetor_posicoes_x = new IntBag(), vetor_posicoes_y = new IntBag();
		neighbours = students.domain.getRadialNeighbors(pos_atual.getX(), 
				pos_atual.getY(), 2, Grid2D.BOUNDED, false); //, includeOrigin, measurementRule, closed, result, xPos, yPos)
		//neighbours = students.domain.getMooreNeighbors(pos_atual.getX(), pos_atual.getY(), 2, Grid2D.BOUNDED, false);
		
		//neighbours = students.domain.getMooreNeighborsAndLocations(pos_atual.getX(), pos_atual.getY(), 2, Grid2D.BOUNDED, neighbours, vetor_posicoes_x, vetor_posicoes_y);
		//getNeighborsExactlyWithinDistance(students.yard.getObjectLocation(this), 0.5, false);  Continuos2D
		
		MutableDouble2D directionVector = new MutableDouble2D();
		MutableDouble2D sumDirections = new MutableDouble2D();
		
		
		Bag neighboursSameColor = new Bag();
		Student neighbour;
		for(int i = 0; i < neighbours.size(); i++)
		{
			neighbour = (Student)neighbours.get(i);
			if(neighbour.getCor() == this.getCor())
			{
				neighboursSameColor.add(neighbour);						
			}			
			//System.out.println(neighbour.getAgitation());
		}
		
		numberOfNeighbours = neighbours.size();
		numberOfNeighboursSameColor = neighboursSameColor.size();
		if(neighbours.size() == 0.0)
			this.segregationDegree = 0.0;
		else 
			this.segregationDegree = numberOfNeighboursSameColor/numberOfNeighbours;
		
//		int angle;		
//		if(neighbours.size() <= 2)
//		{			
//			angle = random.nextInt(360);
//			//students.yard.getObjectLocation(this).x
//			directionVector.setTo(Math.cos(angle), Math.sin(angle));
//			//students.yard.getObjectLocation(this).add(new Double2D(directionVector));
//			sumDirections.addIn(students.yard.getObjectLocation(this).x + Math.cos(angle), students.yard.getObjectLocation(this).y + Math.sin(angle));			
//			//sumDirections = sumDirections.dot(new MutableDouble2D(0.1));
//			students.yard.setObjectLocation(this, new Double2D(sumDirections));
//		}
		
		//System.out.println("Posições dos viinhos com a mesma cor:");
		for(int i = 0; i < neighboursSameColor.size(); i++)
		{
			//neighbour = (Student)neighboursSameColor.get(i)
			//System.out.println(students.domain.getObjectLocation(neighboursSameColor.get(i)));
		}
		Int2D newPos = null; 
		Int2D centro = new Int2D((students.domain.getWidth()/2) + 80,(students.domain.getHeight()/2) - 20);
		int x  = (me.x - centro.x) ;
		int x2 = (me.y - centro.y);
		int y2 = (int) Math.pow(x2, 2);
		int y = (int) Math.pow(x, 2);
		int z = y + y2;
		int d1 = (int) Math.sqrt(z);
		Int2D centro2 = new Int2D((students.domain.getWidth()/2) - 20,(students.domain.getHeight()/2) + 80);
		int xb  = (me.x - centro2.x) ;
		int x2b = (me.y - centro2.y);
		int y2b = (int) Math.pow(x2b, 2);
		int yb = (int) Math.pow(xb, 2);
		int zb = yb + y2b;
		int d2 = (int) Math.sqrt(zb);
		Int2D centro3 = new Int2D((students.domain.getWidth()/2) - 50,(students.domain.getHeight()/2) - 50);
		int xc  = (me.x - centro3.x) ;
		int x2c = (me.y - centro3.y);
		int y2c = (int) Math.pow(x2c, 2);
		int yc = (int) Math.pow(xc, 2);
		int zc = yc + y2c;
		int d3 = (int) Math.sqrt(zc);
		Bag objects = null;
		//System.out.println("Novas posições:");
		
		int angle, new_x, new_y; 
		if((d1 <= raio1 && getCor() == 0) || (d2<= raio1&& getCor() == 0) || (d3<= raio1 && getCor() == 0))
		{
			System.out.println("Ja se estabilizou");
			 
		}else if ((d1 <= raio2 && getCor() == 1 && d1>= raio1) ||(d2 <= raio2 && getCor() == 1 && d2>= raio1) || (d3 <= raio2 && getCor() == 1 && d3>= raio1)){
			System.out.println("Ja se estabilizou");
			
		}else if(((d1<= raio3 && getCor() == 2) && d1>= raio2) || ((d2<= raio3 && getCor() == 2) && d2>= raio2) || ((d3<= raio3 && getCor() == 2) && d3>= raio2)){
			System.out.println("Ja se estabilizou");	
		}else{
			angle = random.nextInt(360);
			new_x = pos_atual.getX() + (int) (Math.cos(angle)*random.nextInt(3));
			new_y = pos_atual.getY() + (int) (Math.sin(angle)*random.nextInt(3));
			newPos = new Int2D(new_x,new_y);
			objects = students.domain.getObjectsAtLocation(newPos.getX(), newPos.getY());
			//ATUALIZA REGIÃO DO AGENTE BASEADO EM newPos
			if (objects == null) //Move para a posição aleatória caso esteja desocupada 
				students.domain.setObjectLocation(this, newPos);
			}
		//newPos = new Int2D( pos_atual.getX() - 1 + random.nextInt(3), pos_atual.getY() -1 + random.nextInt(3));
				// add in a vector to the "teacher" -- the center of the yard, so we don’t go too far away
		//sumForces.addIn(new Double2D((yard.width * 0.5 - me.x) * students.forceToSchoolMultiplier, (yard.height * 0.5 - me.y) * students.forceToSchoolMultiplier));
		// add a bit of randomness
		//sumForces.addIn(new Double2D(students.randomMultiplier * (students.random.nextDouble() * 1.0 - 0.5),
				//students.randomMultiplier * (students.random.nextDouble() * 1.0 - 0.5)));
		//sumForces.addIn(me);
		//students.yard.setObjectLocation(this, new Double2D(sumForces));
	}

	public Region getRegion() {
		return region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}
		
}