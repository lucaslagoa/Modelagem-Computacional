
public class Region {
	
	private String name;
	private double nptc;
	private double ql; 
	private double cost; 
	private int[] xlims;
	private int[] ylims;
	private double[] evaluations;
	private static int eval_index = 0;
	
	public Region(double ptc, double ql, double c, int[] xl, int[] yl, String name)
	{
		this.setNptc(ptc);
		this.setQl(ql);
		this.setCost(c);
		this.xlims = new int[2];
		this.ylims = new int[2];
		this.xlims[0] = xl[0];
		this.xlims[1] = xl[1];
		this.ylims[0] = yl[0];
		this.ylims[1] = yl[1];
		this.setName(name); 
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public double getNptc() {
		return nptc;
	}

	public void setNptc(double nptc) {
		this.nptc = nptc;
	}

	public double getQl() {
		return ql;
	}

	public void setQl(double ql) {
		this.ql = ql;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public double calculateProbToChange(int x, int y)
	{		
		if(inRegion(x,y)){
			return this.cost/this.ql + this.nptc;			
		}
		else return -1;		
	}

	public boolean inRegion(int x, int y)
	{
		if(x >= xlims[0] && x < xlims[1] && y >= ylims[0] && y < ylims[1])
			return true;
		else return false;
	}
	
	public void addEvaluation(double e)
	{
		this.evaluations[eval_index] = e;
		eval_index++; 
	}
	
	

}
