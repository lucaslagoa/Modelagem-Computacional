import java.util.ArrayList;
import java.util.List;

import sim.engine.*;
import sim.util.*;
import sim.field.continuous.*;
import sim.field.network.*;
import sim.field.grid.Grid2D;
import sim.field.grid.SparseGrid2D;

public class Students extends SimState
{
	public Continuous2D yard = new Continuous2D(1.0,100,100); 
	public SparseGrid2D domain = new SparseGrid2D(100,100);///SparseGrid2D
	
	private Region region;
	
	public double TEMPERING_CUT_DOWN = 0.99;
	public double TEMPERING_INITIAL_RANDOM_MULTIPLIER = 10.0;
	public boolean tempering = true;
	public boolean isTempering() { return tempering; }
	public void setTempering(boolean val) { tempering = val; }
	
	private int numStudents = 400;
	private int creation_radius = 10; 
	//double forceToSchoolMultiplier = 0.01;
	//double randomMultiplier = 0.1;
	public Network buddies = new Network(false);
	
	//public Region region1;
	//public Region region2;
	//public Region region3;
	//public Region region4;
	
	private List<Student> students_list; 
	
	public void initializeRegions()
	{
		//region1 = new Region 
		int [] xlims = {domain.getWidth()/2,domain.getWidth()};
		int [] ylims = {0,domain.getHeight()/2};
		//region2 = new Region(0.3,0.3,0.2, xlims, ylims, "region2");
		// /2 é o centro;
		//raio 1 = 5;
		//raio 2 =10 e 3 =15;
		// getPos  =
		
		xlims[0] = 0; 
		xlims[1] = domain.getWidth()/2;
		ylims[0] = domain.getHeight()/2; 
		ylims[1] = domain.getHeight();
		//region3 = new Region(0.1,0.8,0.9,xlims,ylims, "region3");		
	}

	/*public double[] getAgitationDistribution()
	{
		Bag students = buddies.getAllNodes();
		double[] distro = new double[students.numObjs];
		int len = students.size();
		for(int i = 0; i < len; i++)
			distro[i] = ((Student)(students.get(i))).getAgitation();
		return distro;
	}*/

	public Students(long seed)
	{
		super(seed);
	}
	public void start()
	{
		super.start();
		initializeRegions();
		// add the tempering agent
//		if (tempering)
//		{
//			randomMultiplier = TEMPERING_INITIAL_RANDOM_MULTIPLIER;
//			schedule.scheduleRepeating(schedule.EPOCH, 1, new Steppable()
//			{
//				public void step(SimState state) { 
//					if (tempering) randomMultiplier *= TEMPERING_CUT_DOWN; 
//				}
//			});
//		}
		// clear the yard
		yard.clear();
		domain.clear();
		// clear the buddies
		buddies.clear();
		
		System.out.println("BOUNDED = "+ Grid2D.BOUNDED);
		students_list = new ArrayList<>();
		// add some students to the domain
		int posx, posy, xsign, ysign, coin;
		for(int i = 0; i < numStudents/2; i++)
		{
			Student student = new Student();
			student.setCor(random.nextInt(3));
			//student.setCor(0);
			
			///Atribuir a cada estudante uma região 
			coin = random.nextInt(2);
			if(coin == 0)
				{
				//	student.setRegion(region2);
				xsign = -1;
				}
				else 
				{
			//		student.setRegion(region3);
					xsign = 1;
			}		
			
			coin = random.nextInt(2);
			if(coin == 0)
				ysign = -1;
			else 
				ysign = 1;
			
			posx = (int) (domain.getWidth()*0.5 + xsign*random.nextInt(creation_radius));
			posy= (int) (domain.getHeight()*0.5 + ysign*random.nextInt(creation_radius));
			
			domain.setObjectLocation(student, new Int2D(posx,posy));
			
			System.out.println("Estudante criado na posição (" + posx + "," + posy + ") com a cor " + student.getCor() + ".");
			
			
			/*yard.setObjectLocation(student,
					//new Double2D(yard.getWidth() * 0.5 + random.nextDouble()*random.nextInt(2),
						//	yard.getHeight() * 0.5 + random.nextDouble()*random.nextInt(2)));
					new Double2D(yard.getWidth() * 0.5 + random.nextDouble()*random.nextInt(10) - 0.5,
							yard.getHeight() * 0.5 + random.nextDouble()*random.nextInt(10) - 0.5));*/
			
			students_list.add(student);
			buddies.addNode(student);
			schedule.scheduleRepeating(student);
		}
		
		for(int i = 0; i < numStudents/2; i++)
		{
			Student student = new Student();
			student.setCor(random.nextInt(8));
			if(student.getCor() == 3 ||student.getCor() == 4 || student.getCor() == 5){
				student.setCor(2);
			}
			else if(student.getCor() == 6 || student.getCor() == 7){ 
				student.setCor(1);
			}
			//student.setCor(1);
			
			///Atribuir a cada estudante uma região 
			coin = random.nextInt(2);
			if(coin == 0)
			{
				//student.setRegion(region2);
				xsign = -1;
			}
			else 
			{
				//student.setRegion(region3);
				xsign = 1;
			}									
			coin = random.nextInt(2);
			if(coin == 0)
				ysign = -1;
			else 
				ysign = 1;
			
			posx = (int) (domain.getWidth()*0.5 + xsign*random.nextInt(creation_radius));
			posy= (int) (domain.getHeight()*0.5 + ysign*random.nextInt(creation_radius));
			
			domain.setObjectLocation(student, new Int2D(posx,posy));
			
			System.out.println("Estudante criado na posição (" + posx + "," + posy + ") com a cor " + student.getCor() + ".");
			
			
			/*yard.setObjectLocation(student,
					//new Double2D(yard.getWidth() * 0.5 + random.nextDouble()*random.nextInt(2),
						//	yard.getHeight() * 0.5 + random.nextDouble()*random.nextInt(2)));
					new Double2D(yard.getWidth() * 0.5 + random.nextDouble()*random.nextInt(10) - 0.5,
							yard.getHeight() * 0.5 + random.nextDouble()*random.nextInt(10) - 0.5));*/
			
			students_list.add(student);
			buddies.addNode(student);
			schedule.scheduleRepeating(student);
		}
		
		int coin2, k;
		for(Student s: students_list)
		{
			coin = random.nextInt(5);
			k=0;
			while (k < coin)
			{
				coin2 = random.nextInt(students_list.size());
				s.addFriend(students_list.get(coin2));
				k++;
			}						
		}	
		
		// define like/dislike relationships
		Bag students = buddies.getAllNodes();
		for(int i = 0; i < students.size(); i++)
		{
			Object student = students.get(i);
			// who does he like?
			Object studentB = null;
			do
			{
				studentB = students.get(random.nextInt(students.numObjs));
			} while (student == studentB);
			double buddiness = random.nextDouble();
			buddies.addEdge(student, studentB, new Double(buddiness));
			
			// who does he dislike?
			do
			{
				studentB = students.get(random.nextInt(students.numObjs));
			} while (student == studentB);
			buddiness = random.nextDouble();
			buddies.addEdge(student, studentB, new Double( -buddiness));
		}
	}
	public static void main(String[] args)
	{
		doLoop(Students.class, args);
		System.exit(0);
	}
	public Region getRegion() {
		return region;
	}
	public void setRegion(Region region) {
		this.region = region;
	}
}
