import sim.portrayal.network.*;
import sim.portrayal.continuous.*;
import sim.portrayal.grid.SparseGridPortrayal2D;
import sim.engine.*;
import sim.display.*;
import sim.portrayal.simple.*;
import javax.swing.*;
import java.awt.Color;
import sim.portrayal.*;
import java.awt.*;

public class StudentsWithUI extends GUIState
{
	public Display2D display;
	public JFrame displayFrame;
	ContinuousPortrayal2D yardPortrayal = new ContinuousPortrayal2D();
	NetworkPortrayal2D buddiesPortrayal = new NetworkPortrayal2D();
	
	SparseGridPortrayal2D domainPortrayal = new SparseGridPortrayal2D();

	public static void main(String[] args)
	{
		StudentsWithUI vid = new StudentsWithUI();
		Console c = new Console(vid);
		c.setVisible(true);
	}

	public StudentsWithUI() { super(new Students(System.currentTimeMillis())); }
	public StudentsWithUI(SimState state) { super(state); }
	public static String getName() { return "Student Schoolyard Cliques"; }

	public void start()
	{
		super.start();
		setupPortrayals();
	}

	public void load(SimState state)
	{
		super.load(state);
		setupPortrayals();
	}

	public void setupPortrayals()
	{
		Students students = (Students) state;
		
		domainPortrayal.setField(students.domain);
		
		domainPortrayal.setPortrayalForAll(
				new LabelledPortrayal2D(
//						public void draw(Object object, Graphics2D graphics, DrawInfo2D info)
//						{
//							Student student = (Student)object;
//							String label = " position: (" + student.getX() + "," + student.getY() + "); cor: " + student.getCor(); 							
//						}
						
						
				new OvalPortrayal2D()
				{
					Student student;
					public void draw(Object object, Graphics2D graphics, DrawInfo2D info)
					{
						student = (Student)object;
						//int agitationShade = (int) (student.getAgitation() * 255 / 10.0);
						//if (agitationShade > 255) agitationShade = 255;
						//paint = new Color(agitationShade, 0, 255 - agitationShade);
						if (student.getCor() == 0)
						{
							paint = new Color(0,0,201);
						}
						else if(student.getCor() == 1){
							paint = new Color(0 , 255, 0);
						}
						else if(student.getCor() == 2) {
							paint = new Color(204,0,0);
						}
						super.draw(object, graphics, info);
						
					}
				}
				, 5.0, null, Color.black, true)
				);
		
		// tell the portrayals what to portray and how to portray them
//		yardPortrayal.setField( students.yard );
//		yardPortrayal.setPortrayalForAll(
//				new MovablePortrayal2D(
//						new CircledPortrayal2D(
//								new LabelledPortrayal2D(								
//										new OvalPortrayal2D()
//										{
//											public void draw(Object object, Graphics2D graphics, DrawInfo2D info)
//											{
//												Student student = (Student)object;
//												int agitationShade = (int) (student.getAgitation() * 255 / 10.0);
//												if (agitationShade > 255) agitationShade = 255;
//												//paint = new Color(agitationShade, 0, 255 - agitationShade);
//												//if (student.getCor() == 0)
//												//{
//													paint = new Color(69,130,201);
//											//	}
//												//else 
//													//paint = new Color(204,0,0);
//												super.draw(object, graphics, info);
//											}
//										},
//										5.0, null, Color.black, true),
//								0, 5.0, Color.green, true))
//				);

		//buddiesPortrayal.setField( new SpatialNetwork2D( students.yard, students.buddies ) );
		//buddiesPortrayal.setPortrayalForAll(new SimpleEdgePortrayal2D());
		// reschedule the displayer
		display.reset();
		display.setBackdrop(Color.white);
		// redraw the display
		display.repaint();
	}

	public void init(Controller c)
	{
		super.init(c);
		display = new Display2D(800,800,this);
		display.setClipping(false);
		displayFrame = display.createFrame();
		displayFrame.setTitle("Social dynamics in School");
		c.registerFrame(displayFrame);
		// so the frame appears in the "Display" list
		displayFrame.setVisible(true);
		//display.attach( buddiesPortrayal, "Buddies" );
		//display.attach( yardPortrayal, "Yard" );
		display.attach(domainPortrayal, "Discrete domain.");		
	}

	public void quit()
	{
		super.quit();
		if (displayFrame!=null) displayFrame.dispose();
		displayFrame = null;
		display = null;
	}
}
